﻿namespace Clientes
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Creación de las instancias de Cliente sin necesidad de especificar el ID de manera manual
            Cliente cliente1 = new Cliente("Juan", "Pérez", "HolaSoyJuan", PaisEnum.España);
            Cliente cliente2 = new Cliente("Ana", "García", "Ana777", PaisEnum.ReinoUnido);
            Cliente cliente3 = new Cliente("Carlos", "Rodriguez", "HuevosLargos", PaisEnum.EstadosUnidos);
            Cliente cliente4 = new Cliente("Obed", "Rodas", "PedroSanchez", PaisEnum.España);

            Console.WriteLine(cliente1.Id + " " + cliente1.Usuario + " " + cliente1.Pais);
            Console.WriteLine(cliente2.Id + " " + cliente2.Usuario + " " + cliente2.Pais);
            Console.WriteLine(cliente3.Id + " " + cliente3.Usuario + " " + cliente3.Pais);
            Console.WriteLine(cliente4.Id + " " + cliente4.Usuario + " " + cliente4.Pais);

            Console.ReadKey();
        }
    }
}
